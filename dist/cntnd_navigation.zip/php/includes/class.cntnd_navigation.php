<?php

namespace Cntnd\Navigation;

require_once("class.cntnd_util.php");

/**
 * cntnd_navigation Class
 */
class CntndNavigation extends CntndUtil {

}

?>