<style>
<?= file_get_contents($cfgClient[$client]["module"]["path"].'cntnd_list/css/cntnd_navigation.css') ?>
</style>
