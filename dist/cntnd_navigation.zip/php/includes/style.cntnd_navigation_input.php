<style>
<?= file_get_contents($cfgClient[$client]["module"]["path"].'cntnd_navigation/css/cntnd_navigation.css') ?>
</style>
